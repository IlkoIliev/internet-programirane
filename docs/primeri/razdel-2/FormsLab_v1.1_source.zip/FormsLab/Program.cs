using System.Net;
using System.Text;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://127.0.0.1:5000");
var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

// GET: данните са част от URL адреса (query string).
app.MapGet("/register-get", (HttpRequest request) =>
{
    var name = request.Query["name"].ToString();
    var email = request.Query["email"].ToString();
    return HtmlPage("GET — получени данни", $"""
      <p>Метод: <strong>GET</strong></p>
      <p>Име: <strong>{WebUtility.HtmlEncode(name)}</strong></p>
      <p>Имейл: <strong>{WebUtility.HtmlEncode(email)}</strong></p>
      <p>Данните се виждат в адресната лента и в Network → Payload → Query String Parameters.</p>
      """);
});

// POST: стандартен HTML формуляр с application/x-www-form-urlencoded.
app.MapPost("/register-post", async (HttpRequest request) =>
{
    if (!request.HasFormContentType)
        return Results.Content("Очаква се HTML формуляр.", "text/plain; charset=utf-8", statusCode: 415);
    var form = await request.ReadFormAsync();
    var name = form["name"].ToString();
    var email = form["email"].ToString();
    return HtmlPage("POST — получени данни", $"""
      <p>Метод: <strong>POST</strong></p>
      <p>Име: <strong>{WebUtility.HtmlEncode(name)}</strong></p>
      <p>Имейл: <strong>{WebUtility.HtmlEncode(email)}</strong></p>
      <p>Проверете Network → Payload → Form Data.</p>
      """);
});

// Сървърна проверка: не разчита на required или type=email в браузъра.
app.MapPost("/register-validate", async (HttpRequest request) =>
{
    if (!request.HasFormContentType)
        return Results.Content("Очаква се HTML формуляр.", "text/plain; charset=utf-8", statusCode: 415);
    var form = await request.ReadFormAsync();
    var name = form["name"].ToString().Trim();
    var email = form["email"].ToString().Trim();
    var errors = new List<string>();
    if (name.Length < 2 || name.Length > 60) errors.Add("Името трябва да е от 2 до 60 символа.");
    if (email.Length > 254 || !Regex.IsMatch(email, @"^[^\s@]+@[^\s@]+\.[^\s@]+$"))
        errors.Add("Въведете валиден имейл адрес.");
    if (errors.Count > 0)
    {
        var items = string.Join("", errors.Select(e => $"<li>{WebUtility.HtmlEncode(e)}</li>"));
        return HtmlPage("Грешка при проверката", $"<p>Сървърът отхвърли данните:</p><ul>{items}</ul>", 400);
    }
    return HtmlPage("Успешна проверка", $"<p>Данните за <strong>{WebUtility.HtmlEncode(name)}</strong> са валидни.</p><p>Няма запис в база данни.</p>");
});

app.Run();

static IResult HtmlPage(string title, string content, int status = 200)
{
    var html = $"""
    <!doctype html><html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{WebUtility.HtmlEncode(title)} | FormsLab</title><link rel="stylesheet" href="/css/style.css"></head>
    <body><main class="result"><p class="eyebrow">FormsLab · Отговор от сървъра</p><h1>{WebUtility.HtmlEncode(title)}</h1>
    {content}<a class="button" href="/">← Обратно към формулярите</a></main></body></html>
    """;
    return Results.Content(html, "text/html; charset=utf-8", statusCode: status);
}
