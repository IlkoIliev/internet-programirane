const button = document.querySelector('#fetch-test');
const output = document.querySelector('#fetch-result');
button.addEventListener('click', async () => {
  output.textContent = 'Изпращане...';
  try {
    const response = await fetch('/register-post', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Тест', email: 'test@example.com' })
    });
    output.textContent = `HTTP ${response.status} ${response.statusText}\n${await response.text()}`;
  } catch (error) {
    output.textContent = `Грешка: ${error.message}`;
  }
});
